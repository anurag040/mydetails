
  # Design Google News Website

  This is a code bundle for Design Google News Website. The original project is available at https://www.figma.com/design/3reHXyOTxw6RsjOIpzo3lH/Design-Google-News-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  