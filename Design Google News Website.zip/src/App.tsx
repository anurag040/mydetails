import React, { useState, useMemo } from 'react';
import { PrismaHeader } from './components/PrismaHeader';
import { PrismaNavigation } from './components/PrismaNavigation';
import { MainArticle } from './components/MainArticle';
import { RecentNewsSidebar } from './components/RecentNewsSidebar';
import { paymentsData, recentNews, Article, TabType } from './data/paymentsData';

function PaymentsPrisma() {
  const [activeTab, setActiveTab] = useState<TabType>('news');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [loading, setLoading] = useState(false);

  // Get current tab articles
  const currentTabArticles = paymentsData[activeTab] || [];

  // Set default article for each tab
  const defaultArticle = currentTabArticles[0] || null;
  const displayArticle = selectedArticle || defaultArticle;

  // Filter articles based on search query
  const filteredArticles = useMemo(() => {
    if (!searchQuery.trim()) return currentTabArticles;
    
    return currentTabArticles.filter(article =>
      article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.author.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [currentTabArticles, searchQuery]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleTabChange = (tab: TabType) => {
    setLoading(true);
    setActiveTab(tab);
    setSelectedArticle(null); // Reset selected article when changing tabs
    
    // Simulate loading delay for smooth transitions
    setTimeout(() => {
      setLoading(false);
    }, 300);
  };

  const handleArticleSelect = (article: Article) => {
    setSelectedArticle(article);
    // Smooth scroll to top when selecting new article
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Combine current tab articles with recent news for sidebar
  const sidebarArticles = useMemo(() => {
    // If we're filtering, show filtered results in sidebar
    if (searchQuery.trim()) {
      return filteredArticles.slice(1); // Exclude the first one as it's shown in main area
    }
    // Otherwise show recent news
    return recentNews;
  }, [filteredArticles, searchQuery]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      {/* Background Pattern */}
      <div className="fixed inset-0 opacity-30">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-purple-400/20 to-emerald-400/20"></div>
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 20% 50%, rgba(59, 130, 246, 0.1) 0%, transparent 50%),
                           radial-gradient(circle at 80% 20%, rgba(147, 51, 234, 0.1) 0%, transparent 50%),
                           radial-gradient(circle at 40% 80%, rgba(16, 185, 129, 0.1) 0%, transparent 50%)`
        }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        <PrismaHeader onSearch={handleSearch} />
        <PrismaNavigation activeTab={activeTab} onTabChange={handleTabChange} />
        
        <main className="container mx-auto px-6 py-8">
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
            {/* Main Content Area (70%) */}
            <div className="xl:col-span-8">
              {loading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                </div>
              ) : displayArticle ? (
                <MainArticle article={displayArticle} />
              ) : (
                <div className="flex items-center justify-center py-20">
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                      <span className="text-2xl">📰</span>
                    </div>
                    <h3 className="text-xl font-semibold">No articles found</h3>
                    <p className="text-muted-foreground">
                      {searchQuery ? 'Try adjusting your search terms' : 'No articles available for this category'}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar (30%) */}
            <div className="xl:col-span-4">
              <RecentNewsSidebar
                recentNews={sidebarArticles}
                onArticleSelect={handleArticleSelect}
                selectedArticleId={selectedArticle?.id}
              />
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="relative mt-20">
          <div className="glassmorphism border-t border-white/10">
            <div className="container mx-auto px-6 py-12">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="md:col-span-2">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 flex items-center justify-center">
                      <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-white font-bold">P</span>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                        Payments Prisma
                      </h3>
                      <p className="text-sm text-muted-foreground">Financial Intelligence Platform</p>
                    </div>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">
                    Advanced financial intelligence and payment insights platform providing 
                    real-time analysis, security monitoring, and comprehensive incident management 
                    for enterprise financial operations.
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-4">Platform</h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p className="hover:text-foreground cursor-pointer transition-colors">News & Insights</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Payment Analytics</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Incident Management</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Security Monitoring</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-4">Enterprise</h4>
                  <div className="space-y-2 text-sm text-muted-foreground">
                    <p className="hover:text-foreground cursor-pointer transition-colors">API Documentation</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Integration Support</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Enterprise Support</p>
                    <p className="hover:text-foreground cursor-pointer transition-colors">Compliance</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-white/10 mt-8 pt-8 text-center text-sm text-muted-foreground">
                <p>© 2025 Payments Prisma. All rights reserved. | Privacy Policy | Terms of Service | Security</p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default PaymentsPrisma;