import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from './ui/dropdown-menu';
import { Search, Palette, Menu } from 'lucide-react';
import { useTheme, Theme } from './ThemeProvider';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';

interface HeaderProps {
  onSearch: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearch }) => {
  const { theme, setTheme } = useTheme();

  const themeOptions: { value: Theme; label: string; description: string }[] = [
    { value: 'default', label: 'Clean', description: 'Modern & minimalist' },
    { value: 'neon', label: 'Neon', description: 'Vibrant & electric' },
    { value: 'cyberpunk', label: 'Cyberpunk', description: 'Dark & futuristic' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b theme-header backdrop-blur-lg">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64">
                <div className="space-y-4 py-4">
                  <h2 className="text-lg">Menu</h2>
                  <div className="space-y-2">
                    <Button variant="ghost" className="w-full justify-start">Technology</Button>
                    <Button variant="ghost" className="w-full justify-start">Science</Button>
                    <Button variant="ghost" className="w-full justify-start">World</Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg theme-logo flex items-center justify-center">
              <span className="font-bold text-white">N</span>
            </div>
            <h1 className="font-bold text-xl theme-brand-text hidden sm:block">
              FutureNews
            </h1>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-md mx-4 hidden sm:block">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="Search news..."
                className="pl-10 theme-search"
                onChange={(e) => onSearch(e.target.value)}
              />
            </div>
          </div>

          {/* Theme Switcher & Avatar */}
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="theme-theme-button">
                  <Palette className="h-4 w-4" />
                  <span className="hidden sm:inline ml-2">Theme</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {themeOptions.map((option) => (
                  <DropdownMenuItem
                    key={option.value}
                    onClick={() => setTheme(option.value)}
                    className={`cursor-pointer ${theme === option.value ? 'bg-accent' : ''}`}
                  >
                    <div>
                      <div className="font-medium">{option.label}</div>
                      <div className="text-xs text-muted-foreground">{option.description}</div>
                    </div>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Avatar className="w-8 h-8 theme-avatar">
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="mt-3 sm:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder="Search news..."
              className="pl-10 theme-search"
              onChange={(e) => onSearch(e.target.value)}
            />
          </div>
        </div>
      </div>
    </header>
  );
};