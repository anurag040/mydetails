import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Eye, 
  Clock, 
  User, 
  Calendar,
  ChevronDown,
  ChevronUp,
  Share,
  Mail,
  BarChart3,
  AlertCircle,
  CheckCircle2,
  TrendingUp,
  DollarSign,
  Users,
  Zap
} from 'lucide-react';
import { Article } from '../data/paymentsData';

interface MainArticleProps {
  article: Article;
}

export const MainArticle: React.FC<MainArticleProps> = ({ article }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500/20 text-red-700 border-red-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-700 border-yellow-500/30';
      case 'low': return 'bg-green-500/20 text-green-700 border-green-500/30';
      default: return 'bg-gray-500/20 text-gray-700 border-gray-500/30';
    }
  };

  const getSeverityColor = (severity?: string) => {
    switch (severity) {
      case 'critical': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* Main Article Card */}
      <Card className="overflow-hidden glassmorphism border border-white/20 shadow-2xl">
        {/* Hero Image */}
        <div className="relative h-80 overflow-hidden">
          <ImageWithFallback
            src={article.imageUrl}
            alt={article.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
          
          {/* Priority Badge */}
          <div className="absolute top-6 left-6">
            <Badge className={`${getPriorityColor(article.priority)} border backdrop-blur-sm`}>
              {article.priority.toUpperCase()}
            </Badge>
          </div>
          
          {/* Category Badge */}
          <div className="absolute top-6 right-6">
            <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
              {article.category}
            </Badge>
          </div>

          {/* Title Overlay */}
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <h1 className="text-3xl font-bold text-white mb-2 leading-tight">
              {article.title}
            </h1>
            <p className="text-white/90 text-lg leading-relaxed">
              {article.summary}
            </p>
          </div>
        </div>

        {/* Article Meta */}
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{article.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{article.publishedAt}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{article.readTime}</span>
              </div>
            </div>
            
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Eye className="w-4 h-4" />
              <span>{article.views.toLocaleString()} views</span>
            </div>
          </div>

          <Separator className="bg-white/10" />

          {/* CTA Button */}
          <div className="flex justify-center">
            <Button
              onClick={() => setIsExpanded(!isExpanded)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
            >
              {isExpanded ? 'Read Less' : 'Read Full Article'}
              {isExpanded ? 
                <ChevronUp className="ml-2 w-5 h-5" /> : 
                <ChevronDown className="ml-2 w-5 h-5" />
              }
            </Button>
          </div>
        </div>
      </Card>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="space-y-6 animate-in slide-in-from-top-5 duration-500">
          {/* Full Article Content */}
          <Card className="glassmorphism border border-white/20 shadow-xl">
            <div className="p-8">
              <div className="prose prose-lg max-w-none text-foreground">
                <div className="whitespace-pre-line leading-relaxed">
                  {article.fullContent}
                </div>
              </div>
            </div>
          </Card>

          {/* Metrics and Details */}
          {(article.metrics || article.incidentDetails) && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Metrics Card */}
              {article.metrics && (
                <Card className="glassmorphism border border-white/20 shadow-xl">
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-6">
                      <BarChart3 className="w-6 h-6 text-blue-500" />
                      <h3 className="text-xl font-semibold">Key Metrics</h3>
                    </div>
                    
                    <div className="space-y-6">
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                        <div className="flex items-center gap-3">
                          <TrendingUp className="w-5 h-5 text-emerald-500" />
                          <span className="font-medium">Impact Score</span>
                        </div>
                        <span className="text-2xl font-bold text-emerald-500">
                          {article.metrics.impactScore}/10
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                        <div className="flex items-center gap-3">
                          <DollarSign className="w-5 h-5 text-blue-500" />
                          <span className="font-medium">Financial Impact</span>
                        </div>
                        <span className="text-lg font-semibold text-blue-500">
                          {article.metrics.financialImpact}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                        <div className="flex items-center gap-3">
                          <Users className="w-5 h-5 text-purple-500" />
                          <span className="font-medium">Affected Users</span>
                        </div>
                        <span className="text-lg font-semibold text-purple-500">
                          {article.metrics.affectedUsers}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between p-4 rounded-xl bg-white/5 border border-white/10">
                        <div className="flex items-center gap-3">
                          <Zap className={`w-5 h-5 ${getSeverityColor(article.metrics.severity)}`} />
                          <span className="font-medium">Severity Level</span>
                        </div>
                        <Badge className={`${getPriorityColor(article.metrics.severity)} capitalize`}>
                          {article.metrics.severity}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </Card>
              )}

              {/* Incident Details */}
              {article.incidentDetails && (
                <Card className="glassmorphism border border-white/20 shadow-xl">
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-6">
                      <AlertCircle className="w-6 h-6 text-orange-500" />
                      <h3 className="text-xl font-semibold">Incident Details</h3>
                    </div>
                    
                    <div className="space-y-4">
                      <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10">
                        <CheckCircle2 className={`w-5 h-5 ${
                          article.incidentDetails.status === 'resolved' ? 'text-green-500' : 
                          article.incidentDetails.status === 'ongoing' ? 'text-red-500' : 'text-yellow-500'
                        }`} />
                        <div>
                          <p className="font-medium">Status</p>
                          <p className="text-sm text-muted-foreground capitalize">
                            {article.incidentDetails.status}
                          </p>
                        </div>
                      </div>
                      
                      <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                        <p className="font-medium mb-2">Timeline</p>
                        <p className="text-sm text-muted-foreground">
                          {article.incidentDetails.timeline}
                        </p>
                      </div>
                      
                      {article.incidentDetails.rootCause && (
                        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                          <p className="font-medium mb-2">Root Cause</p>
                          <p className="text-sm text-muted-foreground">
                            {article.incidentDetails.rootCause}
                          </p>
                        </div>
                      )}
                      
                      {article.incidentDetails.resolution && (
                        <div className="p-4 rounded-xl bg-white/5 border border-white/10">
                          <p className="font-medium mb-2">Resolution</p>
                          <p className="text-sm text-muted-foreground">
                            {article.incidentDetails.resolution}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              )}
            </div>
          )}

          {/* Footer Actions */}
          <Card className="glassmorphism border border-white/20 shadow-xl">
            <div className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button
                    variant="outline"
                    className="bg-white/5 border-white/20 hover:bg-white/10 transition-all duration-300"
                    onClick={() => setIsExpanded(false)}
                  >
                    <ChevronUp className="w-4 h-4 mr-2" />
                    Read Less
                  </Button>
                  
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Eye className="w-4 h-4" />
                    <span>{article.views.toLocaleString()} views</span>
                  </div>
                </div>
                
                <Button className="bg-gradient-to-r from-emerald-600 to-blue-600 hover:from-emerald-700 hover:to-blue-700 text-white shadow-lg hover:shadow-xl transition-all duration-300">
                  <Mail className="w-4 h-4 mr-2" />
                  Share to Outlook
                </Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};