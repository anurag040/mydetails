import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Clock } from 'lucide-react';

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  category: string;
  source: string;
  imageUrl: string;
  publishedAt: string;
  readTime: string;
}

interface NewsCardProps {
  news: NewsItem;
  size?: 'small' | 'medium' | 'large';
}

export const NewsCard: React.FC<NewsCardProps> = ({ news, size = 'medium' }) => {
  const cardClasses = {
    small: 'col-span-1',
    medium: 'col-span-1 md:col-span-2',
    large: 'col-span-1 md:col-span-3',
  };

  const imageClasses = {
    small: 'h-32',
    medium: 'h-48',
    large: 'h-64',
  };

  return (
    <Card className={`group cursor-pointer overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-lg theme-card ${cardClasses[size]}`}>
      <div className="relative">
        <ImageWithFallback
          src={news.imageUrl}
          alt={news.title}
          className={`w-full object-cover transition-transform duration-300 group-hover:scale-105 ${imageClasses[size]}`}
        />
        <div className="absolute top-3 left-3">
          <Badge variant="secondary" className="theme-badge">
            {news.category}
          </Badge>
        </div>
      </div>
      
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span className="theme-source">{news.source}</span>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{news.readTime}</span>
          </div>
        </div>
        
        <h3 className="line-clamp-2 leading-tight theme-title">
          {news.title}
        </h3>
        
        <p className="text-sm text-muted-foreground line-clamp-3 theme-summary">
          {news.summary}
        </p>
        
        <div className="text-xs text-muted-foreground">
          {news.publishedAt}
        </div>
      </div>
    </Card>
  );
};