import React from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Search, Bell, Settings, User } from 'lucide-react';
import { Badge } from './ui/badge';

interface PrismaHeaderProps {
  onSearch: (query: string) => void;
}

export const PrismaHeader: React.FC<PrismaHeaderProps> = ({ onSearch }) => {
  return (
    <header className="sticky top-0 z-50 w-full glassmorphism border-b border-white/10 backdrop-blur-xl">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 via-purple-500 to-emerald-500 flex items-center justify-center shadow-2xl">
                <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                  <span className="text-white font-bold text-lg">P</span>
                </div>
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full border-2 border-white animate-pulse"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-emerald-600 bg-clip-text text-transparent">
                Payments Prisma
              </h1>
              <p className="text-xs text-muted-foreground">Financial Intelligence Platform</p>
            </div>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5 group-focus-within:text-blue-500 transition-colors" />
              <Input
                placeholder="Search financial news, incidents, or insights..."
                className="pl-12 pr-4 h-12 bg-white/5 border-white/10 rounded-2xl backdrop-blur-sm focus:bg-white/10 focus:border-blue-500/50 transition-all duration-300 placeholder:text-muted-foreground/70"
                onChange={(e) => onSearch(e.target.value)}
              />
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-emerald-500/10 opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="relative p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all duration-300"
            >
              <Bell className="h-5 w-5" />
              <Badge className="absolute -top-2 -right-2 w-5 h-5 p-0 text-xs bg-red-500 hover:bg-red-500">
                3
              </Badge>
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition-all duration-300"
            >
              <Settings className="h-5 w-5" />
            </Button>

            <div className="w-px h-8 bg-white/10"></div>

            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium">Sarah Mitchell</p>
                <p className="text-xs text-muted-foreground">Senior Analyst</p>
              </div>
              <Avatar className="w-10 h-10 border-2 border-white/20 shadow-lg">
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-500 text-white font-semibold">
                  SM
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};