import React from 'react';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Newspaper, 
  CreditCard, 
  AlertTriangle,
  TrendingUp,
  Shield,
  Activity
} from 'lucide-react';
import { TabType } from '../data/paymentsData';

interface PrismaNavigationProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export const PrismaNavigation: React.FC<PrismaNavigationProps> = ({ 
  activeTab, 
  onTabChange 
}) => {
  const tabs = [
    { 
      id: 'news' as TabType, 
      label: 'News', 
      icon: Newspaper,
      description: 'Latest financial news',
      badge: null,
      gradient: 'from-blue-500 to-blue-600'
    },
    { 
      id: 'payments' as TabType, 
      label: 'Payments Insights', 
      icon: CreditCard,
      description: 'Transaction analytics',
      badge: { text: '2', color: 'bg-emerald-500' },
      gradient: 'from-emerald-500 to-emerald-600'
    },
    { 
      id: 'incidents' as TabType, 
      label: 'Incident Insights', 
      icon: AlertTriangle,
      description: 'Security & operational alerts',
      badge: { text: '1', color: 'bg-red-500' },
      gradient: 'from-red-500 to-red-600'
    },
  ];

  return (
    <div className="sticky top-[89px] z-40 glassmorphism border-b border-white/10 backdrop-blur-xl">
      <div className="container mx-auto px-6 py-4">
        <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as TabType)}>
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-flex bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className={`
                    relative flex items-center justify-center gap-3 px-6 py-3 rounded-xl transition-all duration-300
                    ${isActive 
                      ? `bg-gradient-to-r ${tab.gradient} text-white shadow-lg shadow-current/25` 
                      : 'text-muted-foreground hover:text-foreground hover:bg-white/10'
                    }
                  `}
                >
                  <div className="flex items-center gap-2">
                    <Icon className={`w-5 h-5 ${isActive ? 'drop-shadow-sm' : ''}`} />
                    <div className="flex flex-col items-start">
                      <span className="font-medium text-sm">{tab.label}</span>
                      <span className={`text-xs ${isActive ? 'text-white/80' : 'text-muted-foreground/70'} hidden xl:block`}>
                        {tab.description}
                      </span>
                    </div>
                    {tab.badge && (
                      <Badge className={`${tab.badge.color} text-white text-xs px-2 py-1 ml-2 animate-pulse`}>
                        {tab.badge.text}
                      </Badge>
                    )}
                  </div>
                  
                  {isActive && (
                    <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-white/10 via-transparent to-white/10 pointer-events-none"></div>
                  )}
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>

        {/* Tab Statistics */}
        <div className="flex items-center gap-6 mt-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <span>Market trending up 2.3%</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-500" />
            <span>Security status: Optimal</span>
          </div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-purple-500" />
            <span>System load: 67%</span>
          </div>
        </div>
      </div>
    </div>
  );
};