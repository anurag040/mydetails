import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { 
  Clock, 
  Eye, 
  TrendingUp,
  ChevronRight,
  Newspaper
} from 'lucide-react';
import { Article } from '../data/paymentsData';

interface RecentNewsSidebarProps {
  recentNews: Article[];
  onArticleSelect: (article: Article) => void;
  selectedArticleId?: string;
}

export const RecentNewsSidebar: React.FC<RecentNewsSidebarProps> = ({ 
  recentNews, 
  onArticleSelect,
  selectedArticleId 
}) => {
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="glassmorphism border border-white/20 shadow-xl">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 rounded-xl bg-gradient-to-r from-blue-500 to-purple-500">
              <Newspaper className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold">Recent News</h2>
              <p className="text-sm text-muted-foreground">Latest financial updates</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2 text-emerald-600">
              <TrendingUp className="w-4 h-4" />
              <span>12 new articles today</span>
            </div>
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
          </div>
        </div>
      </Card>

      {/* Recent News List */}
      <Card className="glassmorphism border border-white/20 shadow-xl overflow-hidden">
        <ScrollArea className="h-[600px]">
          <div className="p-2">
            {recentNews.map((article, index) => (
              <div
                key={article.id}
                className={`
                  group relative p-4 rounded-2xl cursor-pointer transition-all duration-300 mb-2
                  hover:bg-white/10 hover:shadow-lg hover:scale-[1.02]
                  ${selectedArticleId === article.id ? 'bg-white/10 shadow-lg' : ''}
                `}
                onClick={() => onArticleSelect(article)}
              >
                <div className="flex gap-4">
                  {/* Thumbnail */}
                  <div className="relative flex-shrink-0">
                    <div className="w-20 h-20 rounded-xl overflow-hidden">
                      <ImageWithFallback
                        src={article.imageUrl}
                        alt={article.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                    
                    {/* Priority Indicator */}
                    <div className={`absolute -top-1 -right-1 w-4 h-4 rounded-full ${getPriorityColor(article.priority)} border-2 border-white`}></div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className="bg-blue-500/20 text-blue-700 border-blue-500/30 text-xs">
                        {article.category}
                      </Badge>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-blue-500 group-hover:translate-x-1 transition-all duration-200" />
                    </div>
                    
                    <h3 className="font-semibold text-sm leading-tight mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
                      {article.title}
                    </h3>
                    
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3 leading-relaxed">
                      {article.summary}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>{article.publishedAt}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="w-3 h-3" />
                          <span>{article.views.toLocaleString()}</span>
                        </div>
                      </div>
                      <span className="text-blue-600 font-medium">{article.readTime}</span>
                    </div>
                  </div>
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-emerald-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Card>

      {/* Trending Topics */}
      <Card className="glassmorphism border border-white/20 shadow-xl">
        <div className="p-6">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
            Trending Topics
          </h3>
          
          <div className="space-y-3">
            {[
              { topic: 'Quantum Encryption', count: '2.3k mentions' },
              { topic: 'CBDC Implementation', count: '1.8k mentions' },
              { topic: 'AI Fraud Detection', count: '1.5k mentions' },
              { topic: 'Real-time Payments', count: '1.2k mentions' },
            ].map((item, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer group">
                <div>
                  <p className="font-medium text-sm group-hover:text-blue-600 transition-colors">#{item.topic}</p>
                  <p className="text-xs text-muted-foreground">{item.count}</p>
                </div>
                <div className="w-2 h-8 rounded-full bg-gradient-to-t from-blue-500 to-emerald-500"></div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
};