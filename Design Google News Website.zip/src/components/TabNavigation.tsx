import React from 'react';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { Cpu, Rocket, Globe } from 'lucide-react';

export type NewsTab = 'technology' | 'science' | 'world';

interface TabNavigationProps {
  activeTab: NewsTab;
  onTabChange: (tab: NewsTab) => void;
}

export const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'technology' as NewsTab, label: 'Technology', icon: Cpu },
    { id: 'science' as NewsTab, label: 'Science', icon: Rocket },
    { id: 'world' as NewsTab, label: 'World', icon: Globe },
  ];

  return (
    <div className="sticky top-[73px] z-40 bg-background/80 backdrop-blur-sm border-b">
      <div className="container mx-auto px-4 py-2">
        <Tabs value={activeTab} onValueChange={(value) => onTabChange(value as NewsTab)}>
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-flex theme-tabs">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <TabsTrigger
                  key={tab.id}
                  value={tab.id}
                  className="flex items-center gap-2 theme-tab"
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{tab.label}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>
        </Tabs>
      </div>
    </div>
  );
};