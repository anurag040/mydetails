import { NewsItem } from '../components/NewsCard';

export const mockNews: Record<string, NewsItem[]> = {
  technology: [
    {
      id: 'tech-1',
      title: 'Revolutionary AI Breakthrough: New Neural Network Architecture Achieves Human-Level Reasoning',
      summary: 'Scientists have developed a groundbreaking neural network that demonstrates unprecedented reasoning capabilities, potentially transforming how we approach artificial intelligence development.',
      category: 'AI & ML',
      source: 'TechVision',
      imageUrl: 'https://images.unsplash.com/photo-1625314887424-9f190599bd56?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpZmljaWFsJTIwaW50ZWxsaWdlbmNlJTIwcm9ib3R8ZW58MXx8fHwxNzU3MDUxOTEyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '2 hours ago',
      readTime: '5 min read'
    },
    {
      id: 'tech-2',
      title: 'Quantum Computing Milestone: 1000-Qubit Processor Achieves Error Correction',
      summary: 'A major breakthrough in quantum computing brings us closer to practical quantum computers with unprecedented processing power.',
      category: 'Quantum',
      source: 'Future Computing',
      imageUrl: 'https://images.unsplash.com/photo-1568952433726-3896e3881c65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwaW5ub3ZhdGlvbnxlbnwxfHx8fDE3NTcxMjk0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '4 hours ago',
      readTime: '7 min read'
    },
    {
      id: 'tech-3',
      title: 'Cybersecurity Alert: New Zero-Day Vulnerability Affects Millions of Devices',
      summary: 'Security researchers have discovered a critical vulnerability that could allow hackers to gain unauthorized access to smart devices.',
      category: 'Security',
      source: 'CyberWatch',
      imageUrl: 'https://images.unsplash.com/photo-1660644808219-1f103401bc85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwZGlnaXRhbHxlbnwxfHx8fDE3NTcwNzYzNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '6 hours ago',
      readTime: '4 min read'
    },
    {
      id: 'tech-4',
      title: 'Metaverse Revolution: New VR Technology Promises Seamless Digital Experiences',
      summary: 'Latest virtual reality innovations bring us closer to truly immersive digital worlds with haptic feedback and neural interfaces.',
      category: 'VR/AR',
      source: 'Digital Frontier',
      imageUrl: 'https://images.unsplash.com/photo-1568952433726-3896e3881c65?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNobm9sb2d5JTIwaW5ub3ZhdGlvbnxlbnwxfHx8fDE3NTcxMjk0MjZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '8 hours ago',
      readTime: '6 min read'
    },
    {
      id: 'tech-5',
      title: 'Blockchain Innovation: New Protocol Achieves 100,000 Transactions Per Second',
      summary: 'Revolutionary blockchain technology overcomes scalability issues, paving the way for mainstream cryptocurrency adoption.',
      category: 'Blockchain',
      source: 'CryptoNews',
      imageUrl: 'https://images.unsplash.com/photo-1660644808219-1f103401bc85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwZGlnaXRhbHxlbnwxfHx8fDE3NTcwNzYzNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '12 hours ago',
      readTime: '5 min read'
    }
  ],

  science: [
    {
      id: 'sci-1',
      title: 'Mars Mission Success: First Samples Return to Earth After Historic Journey',
      summary: 'NASA\'s Mars Sample Return mission has successfully brought Martian soil samples back to Earth, potentially revealing signs of ancient life.',
      category: 'Space',
      source: 'Space Explorer',
      imageUrl: 'https://images.unsplash.com/photo-1517976487492-5750f3195933?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMHNjaWVuY2V8ZW58MXx8fHwxNzU3MTQ2OTAxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '1 hour ago',
      readTime: '8 min read'
    },
    {
      id: 'sci-2',
      title: 'Climate Breakthrough: Revolutionary Carbon Capture Technology Deployed at Scale',
      summary: 'New atmospheric carbon capture technology could remove billions of tons of CO2, offering hope in the fight against climate change.',
      category: 'Climate',
      source: 'EcoScience',
      imageUrl: 'https://images.unsplash.com/photo-1565011471985-8a450248b005?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGltYXRlJTIwY2hhbmdlJTIwZW52aXJvbm1lbnR8ZW58MXx8fHwxNzU3MTQ2OTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '3 hours ago',
      readTime: '6 min read'
    },
    {
      id: 'sci-3',
      title: 'Medical Miracle: Gene Therapy Cures Rare Genetic Disease in Clinical Trial',
      summary: 'Groundbreaking gene editing technique shows 100% success rate in treating previously incurable genetic disorders.',
      category: 'Medicine',
      source: 'Medical Today',
      imageUrl: 'https://images.unsplash.com/photo-1517976487492-5750f3195933?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMHNjaWVuY2V8ZW58MXx8fHwxNzU3MTQ2OTAxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '5 hours ago',
      readTime: '7 min read'
    },
    {
      id: 'sci-4',
      title: 'Deep Ocean Discovery: New Species Found in Mariana Trench',
      summary: 'Scientists discover extraordinary new life forms in the deepest parts of our oceans, expanding our understanding of extreme environments.',
      category: 'Biology',
      source: 'Ocean Research',
      imageUrl: 'https://images.unsplash.com/photo-1565011471985-8a450248b005?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGltYXRlJTIwY2hhbmdlJTIwZW52aXJvbm1lbnR8ZW58MXx8fHwxNzU3MTQ2OTAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '7 hours ago',
      readTime: '5 min read'
    },
    {
      id: 'sci-5',
      title: 'Particle Physics Breakthrough: New Subatomic Particle Challenges Standard Model',
      summary: 'CERN researchers announce discovery of previously unknown particle that could revolutionize our understanding of fundamental physics.',
      category: 'Physics',
      source: 'Particle News',
      imageUrl: 'https://images.unsplash.com/photo-1517976487492-5750f3195933?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMHNjaWVuY2V8ZW58MXx8fHwxNzU3MTQ2OTAxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '10 hours ago',
      readTime: '9 min read'
    }
  ],

  world: [
    {
      id: 'world-1',
      title: 'Global Climate Summit Reaches Historic Agreement on Carbon Neutrality by 2030',
      summary: 'World leaders commit to unprecedented climate action with binding agreements and $2 trillion in green technology investments.',
      category: 'Politics',
      source: 'Global News',
      imageUrl: 'https://images.unsplash.com/photo-1584573062942-d46bb3aee3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG5ld3MlMjBnbG9iYWx8ZW58MXx8fHwxNzU3MDU4MjE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '30 minutes ago',
      readTime: '6 min read'
    },
    {
      id: 'world-2',
      title: 'Economic Recovery: Global Markets Surge as Trade Relations Improve',
      summary: 'International trade agreements boost economic confidence, with markets reaching new highs across major economies.',
      category: 'Economy',
      source: 'World Economy',
      imageUrl: 'https://images.unsplash.com/photo-1584573062942-d46bb3aee3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG5ld3MlMjBnbG9iYWx8ZW58MXx8fHwxNzU3MDU4MjE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '2 hours ago',
      readTime: '4 min read'
    },
    {
      id: 'world-3',
      title: 'Humanitarian Crisis Averted: International Aid Reaches Remote Regions',
      summary: 'Coordinated global response successfully delivers emergency aid to areas affected by natural disasters, saving thousands of lives.',
      category: 'Humanitarian',
      source: 'Relief News',
      imageUrl: 'https://images.unsplash.com/photo-1584573062942-d46bb3aee3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG5ld3MlMjBnbG9iYWx8ZW58MXx8fHwxNzU3MDU4MjE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '4 hours ago',
      readTime: '5 min read'
    },
    {
      id: 'world-4',
      title: 'Cultural Renaissance: Global Arts Festival Celebrates Human Creativity',
      summary: 'Artists from 100 countries showcase innovative works that bridge cultural divides and promote international understanding.',
      category: 'Culture',
      source: 'Arts Global',
      imageUrl: 'https://images.unsplash.com/photo-1584573062942-d46bb3aee3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG5ld3MlMjBnbG9iYWx8ZW58MXx8fHwxNzU3MDU4MjE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '6 hours ago',
      readTime: '7 min read'
    },
    {
      id: 'world-5',
      title: 'Education Revolution: Global Digital Learning Initiative Reaches 1 Billion Students',
      summary: 'Massive international collaboration brings quality education to underserved communities worldwide through innovative technology.',
      category: 'Education',
      source: 'Education Today',
      imageUrl: 'https://images.unsplash.com/photo-1584573062942-d46bb3aee3fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG5ld3MlMjBnbG9iYWx8ZW58MXx8fHwxNzU3MDU4MjE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '9 hours ago',
      readTime: '8 min read'
    }
  ]
};