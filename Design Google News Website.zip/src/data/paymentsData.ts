export interface Article {
  id: string;
  title: string;
  summary: string;
  fullContent: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  source: string;
  author: string;
  imageUrl: string;
  publishedAt: string;
  readTime: string;
  views: number;
  metrics?: {
    impactScore: number;
    financialImpact: string;
    affectedUsers: string;
    severity: 'critical' | 'high' | 'medium' | 'low';
  };
  incidentDetails?: {
    status: 'ongoing' | 'resolved' | 'investigating';
    timeline: string;
    rootCause?: string;
    resolution?: string;
  };
}

export type TabType = 'news' | 'payments' | 'incidents';

export const paymentsData: Record<TabType, Article[]> = {
  news: [
    {
      id: 'news-1',
      title: 'Global Payment Networks Experience Unprecedented Growth in Digital Transactions',
      summary: 'Digital payment volumes surge 47% year-over-year as consumers embrace contactless and mobile payment solutions worldwide.',
      fullContent: `The global payments landscape has witnessed extraordinary transformation in 2024, with digital transaction volumes reaching record highs across all major markets. According to the latest industry reports, contactless payments now account for 68% of all in-person transactions, marking a significant shift in consumer behavior.

Key highlights from the report:
• Mobile wallet adoption increased by 52% globally
• Cross-border payment volumes grew 34% year-over-year  
• Real-time payment systems processed over 195 billion transactions
• Cryptocurrency payment integration rose by 28% among merchants

The surge in digital payments has been driven by enhanced security measures, improved user experience, and widespread merchant adoption. Major payment processors report that transaction success rates have improved to 99.7%, while processing times have decreased by an average of 23%.

Financial institutions are investing heavily in payment infrastructure modernization, with over $47 billion allocated to payment technology upgrades in 2024. This investment focuses on real-time payment capabilities, fraud prevention, and seamless integration with emerging technologies like blockchain and artificial intelligence.

The trend is expected to continue through 2025, with analysts predicting digital payment volumes will reach $12.9 trillion globally.`,
      category: 'Market Trends',
      priority: 'high',
      source: 'Financial Technology Today',
      author: 'Sarah Chen, Senior Financial Analyst',
      imageUrl: 'https://images.unsplash.com/photo-1728044849313-cd9de74be59d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjB0ZWNobm9sb2d5JTIwZGlnaXRhbCUyMHBheW1lbnRzfGVufDF8fHx8MTc1NzE0NzM4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '2 hours ago',
      readTime: '6 min read',
      views: 15742,
      metrics: {
        impactScore: 8.7,
        financialImpact: '$2.3T transaction volume',
        affectedUsers: '3.2B users globally',
        severity: 'high'
      }
    },
    {
      id: 'news-2',
      title: 'Central Bank Digital Currencies (CBDCs) Gain Momentum with 12 New Pilot Programs',
      summary: 'Major economies launch comprehensive CBDC trials as digital currency adoption accelerates across government and private sectors.',
      fullContent: `Central banks worldwide are accelerating their digital currency initiatives, with 12 new pilot programs launched in Q4 2024. These comprehensive trials represent a significant step toward mainstream CBDC adoption, potentially reshaping the global monetary system.

The pilot programs span across major economies including the European Union, Japan, Canada, and several emerging markets. Each program focuses on different aspects of CBDC implementation, from retail payments to wholesale banking operations.

Key developments include:
• The European Central Bank's digital euro pilot processes over 1 million transactions daily
• Japan's digital yen shows promising results in cross-border payment efficiency
• Canada's CBDC trial demonstrates 3-second settlement times for domestic transfers
• Emerging markets report 89% user satisfaction rates in CBDC usability studies

Privacy and security remain top priorities, with advanced encryption and zero-knowledge proof technologies being integrated into CBDC architectures. The pilots are testing various models including account-based and token-based approaches.

Industry experts suggest that widespread CBDC implementation could begin as early as 2026, with potential benefits including reduced payment costs, improved financial inclusion, and enhanced monetary policy effectiveness.`,
      category: 'Regulatory',
      priority: 'high',
      source: 'Central Banking Review',
      author: 'Michael Rodriguez, Policy Analyst',
      imageUrl: 'https://images.unsplash.com/photo-1639305239869-8ef28a21b313?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwY3J5cHRvY3VycmVuY3klMjBmaW5hbmNlfGVufDF8fHx8MTc1NzE0NzM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '4 hours ago',
      readTime: '8 min read',
      views: 12389
    }
  ],

  payments: [
    {
      id: 'payments-1',
      title: 'AI-Powered Fraud Detection System Prevents $847M in Fraudulent Transactions',
      summary: 'Advanced machine learning algorithms achieve 99.6% accuracy rate in real-time fraud detection, setting new industry standards.',
      fullContent: `A revolutionary AI-powered fraud detection system has successfully prevented $847 million in fraudulent transactions over the past quarter, representing a 73% improvement over traditional rule-based systems. The breakthrough technology combines machine learning, behavioral analytics, and real-time risk assessment to identify and block suspicious activities within milliseconds.

The system analyzes over 2,000 data points for each transaction, including:
• Transaction patterns and velocity
• Device fingerprinting and geolocation data
• Behavioral biometrics and user interaction patterns
• Network analysis and merchant risk profiles
• Historical fraud patterns and emerging threat intelligence

Key performance metrics demonstrate the system's effectiveness:
• 99.6% fraud detection accuracy rate
• 0.12% false positive rate (industry average: 2.3%)
• Average detection time: 47 milliseconds
• $847M in prevented fraudulent transactions
• 94% reduction in manual review requirements

The technology has been particularly effective in identifying sophisticated fraud schemes, including account takeovers, synthetic identity fraud, and coordinated attack patterns. The system's ability to adapt and learn from new fraud vectors has resulted in continuous improvement in detection capabilities.

Financial institutions implementing this technology report significant improvements in customer experience, with legitimate transactions processing seamlessly while fraudulent activities are blocked instantly. The reduced false positive rate has also decreased customer friction, leading to higher conversion rates and improved customer satisfaction.

Looking ahead, the system is being enhanced with quantum-resistant encryption and federated learning capabilities to maintain its effectiveness against evolving cyber threats.`,
      category: 'Security & Fraud',
      priority: 'high',
      source: 'Payments Security Journal',
      author: 'Dr. Emily Zhang, Cybersecurity Researcher',
      imageUrl: 'https://images.unsplash.com/photo-1727974290663-48ca35264028?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwZGF0YSUyMGJyZWFjaHxlbnwxfHx8fDE3NTcxNDczODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '1 hour ago',
      readTime: '7 min read',
      views: 23156,
      metrics: {
        impactScore: 9.4,
        financialImpact: '$847M fraud prevented',
        affectedUsers: '45M+ protected accounts',
        severity: 'critical'
      }
    },
    {
      id: 'payments-2',
      title: 'Real-Time Payment Network Achieves 99.99% Uptime in Global Stress Test',
      summary: 'Infrastructure resilience testing processes 2.3 billion transactions without interruption, validating system robustness.',
      fullContent: `The global real-time payment network has successfully completed its most comprehensive stress test to date, processing 2.3 billion transactions over 72 hours while maintaining 99.99% uptime. This landmark achievement demonstrates the network's ability to handle extreme transaction volumes while ensuring consistent performance and reliability.

The stress test simulated various scenarios including:
• Peak holiday shopping traffic (5x normal volume)
• Coordinated cyberattacks and DDoS attempts
• Infrastructure failures and failover scenarios
• Cross-border payment surge conditions
• High-frequency trading and algorithmic payments

Throughout the testing period, the network maintained exceptional performance metrics:
• Average transaction processing time: 1.2 seconds
• Peak throughput: 127,000 transactions per second
• Zero data loss incidents
• 99.99% success rate for legitimate transactions
• Sub-50ms latency for 95% of transactions

The test validated critical infrastructure components including distributed ledger systems, quantum-encrypted communication channels, and AI-powered load balancing algorithms. The network's ability to automatically scale resources and reroute traffic during simulated outages proved instrumental in maintaining service availability.

Financial institutions participating in the test reported high confidence in the network's ability to support their operations during peak demand periods. The successful completion of this stress test positions the real-time payment network as the most reliable infrastructure for global financial transactions.

Phase 2 testing will focus on quantum computing resilience and integration with emerging CBDC systems, scheduled for Q2 2025.`,
      category: 'Infrastructure',
      priority: 'medium',
      source: 'Global Payments Network',
      author: 'Technical Operations Team',
      imageUrl: 'https://images.unsplash.com/photo-1592698765727-387c9464cd7f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5raW5nJTIwZGlnaXRhbCUyMHRyYW5zZm9ybWF0aW9ufGVufDF8fHx8MTc1NzE0NzM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '3 hours ago',
      readTime: '5 min read',
      views: 8734
    }
  ],

  incidents: [
    {
      id: 'incident-1',
      title: 'Major Payment Processor Resolves Service Disruption Affecting 2.1M Merchants',
      summary: 'Payment processing delays lasted 47 minutes before full service restoration. Comprehensive investigation underway.',
      fullContent: `A significant service disruption affecting one of the world's largest payment processors was successfully resolved after 47 minutes of intermittent processing delays. The incident impacted approximately 2.1 million merchants globally, with transaction approval rates dropping to 73% during the peak disruption period.

The incident began at 14:32 UTC when automated monitoring systems detected anomalous latency patterns in the core transaction processing infrastructure. Within 90 seconds, incident response protocols were activated and engineering teams were mobilized to investigate and resolve the issue.

Timeline of events:
• 14:32 UTC - Initial latency alerts triggered
• 14:34 UTC - Incident response team activated  
• 14:41 UTC - Root cause identified: database connection pool exhaustion
• 14:52 UTC - Emergency capacity scaling implemented
• 15:19 UTC - Full service restoration confirmed

The root cause was traced to an unexpected surge in transaction volume combined with a software bug in the connection pooling logic. This created a cascading effect that overwhelmed database connections during peak processing periods.

Immediate remediation actions included:
• Emergency scaling of database connection pools
• Deployment of hotfix for connection management bug
• Activation of secondary processing centers
• Enhanced monitoring for similar patterns

Customer impact analysis shows that while 2.1 million merchants were potentially affected, only 12% experienced actual transaction failures due to automatic retry mechanisms and redundant processing pathways. No customer financial data was compromised, and all failed transactions were automatically reprocessed within 30 minutes of service restoration.

A comprehensive post-incident review is underway to identify additional preventive measures and strengthen system resilience against similar scenarios.`,
      category: 'System Outage',
      priority: 'high',
      source: 'Internal Incident Report',
      author: 'Site Reliability Engineering Team',
      imageUrl: 'https://images.unsplash.com/photo-1727974290663-48ca35264028?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwZGF0YSUyMGJyZWFjaHxlbnwxfHx8fDE3NTcxNDczODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      publishedAt: '6 hours ago',
      readTime: '4 min read',
      views: 31247,
      incidentDetails: {
        status: 'resolved',
        timeline: '47 minutes',
        rootCause: 'Database connection pool exhaustion due to traffic surge and software bug',
        resolution: 'Emergency scaling, hotfix deployment, and enhanced monitoring implementation'
      },
      metrics: {
        impactScore: 7.8,
        financialImpact: '$2.3M estimated revenue impact',
        affectedUsers: '2.1M merchants, ~85M end users',
        severity: 'high'
      }
    }
  ]
};

export const recentNews: Article[] = [
  {
    id: 'recent-1',
    title: 'Quantum-Safe Encryption Standards Released for Financial Institutions',
    summary: 'New cryptographic protocols designed to withstand quantum computing attacks.',
    fullContent: '',
    category: 'Security',
    priority: 'medium',
    source: 'Crypto Standards Board',
    author: 'Tech Team',
    imageUrl: 'https://images.unsplash.com/photo-1639305239869-8ef28a21b313?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwY3J5cHRvY3VycmVuY3klMjBmaW5hbmNlfGVufDF8fHx8MTc1NzE0NzM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    publishedAt: '30 min ago',
    readTime: '3 min read',
    views: 5629
  },
  {
    id: 'recent-2',
    title: 'Cross-Border Payment Costs Drop 23% Following New International Agreement',
    summary: 'G20 initiative reduces remittance fees and improves processing speed.',
    fullContent: '',
    category: 'Regulation',
    priority: 'medium',
    source: 'International Finance',
    author: 'Policy Team',
    imageUrl: 'https://images.unsplash.com/photo-1592698765727-387c9464cd7f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5raW5nJTIwZGlnaXRhbCUyMHRyYW5zZm9ybWF0aW9ufGVufDF8fHx8MTc1NzE0NzM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    publishedAt: '1 hour ago',
    readTime: '4 min read',
    views: 4892
  },
  {
    id: 'recent-3',
    title: 'Biometric Authentication Adoption Surges 67% in Mobile Banking',
    summary: 'Fingerprint and face recognition become standard for secure payments.',
    fullContent: '',
    category: 'Innovation',
    priority: 'low',
    source: 'Mobile Banking Today',
    author: 'Research Team',
    imageUrl: 'https://images.unsplash.com/photo-1728044849313-cd9de74be59d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjB0ZWNobm9sb2d5JTIwZGlnaXRhbCUyMHBheW1lbnRzfGVufDF8fHx8MTc1NzE0NzM4MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    publishedAt: '2 hours ago',
    readTime: '2 min read',
    views: 3247
  },
  {
    id: 'recent-4',
    title: 'Fintech Startups Raise Record $12.7B in Q4 Funding',
    summary: 'Payment technology companies lead venture capital investments.',
    fullContent: '',
    category: 'Investment',
    priority: 'medium',
    source: 'Venture Capital Daily',
    author: 'Investment Team',
    imageUrl: 'https://images.unsplash.com/photo-1639305239869-8ef28a21b313?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibG9ja2NoYWluJTIwY3J5cHRvY3VycmVuY3klMjBmaW5hbmNlfGVufDF8fHx8MTc1NzE0NzM4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    publishedAt: '4 hours ago',
    readTime: '5 min read',
    views: 7123
  },
  {
    id: 'recent-5',
    title: 'Smart Contract Vulnerabilities Decline 45% with New Audit Tools',
    summary: 'Advanced static analysis improves blockchain security standards.',
    fullContent: '',
    category: 'Security',
    priority: 'medium',
    source: 'Blockchain Security',
    author: 'Security Team',
    imageUrl: 'https://images.unsplash.com/photo-1727974290663-48ca35264028?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWJlcnNlY3VyaXR5JTIwZGF0YSUyMGJyZWFjaHxlbnwxfHx8fDE3NTcxNDczODR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    publishedAt: '6 hours ago',
    readTime: '6 min read',
    views: 2891
  }
];