import { Component, OnInit, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { VideoService, Video } from '../../services/video.service';

@Component({
  selector: 'app-video-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './video-list.component.html',
  styleUrls: ['./video-list.component.scss'],

})
export class VideoListComponent implements OnInit {
  @ViewChildren('videoPreview') videoPreviews!: QueryList<ElementRef<HTMLVideoElement>>;
  videos: Video[] = [];
  activePreviews: boolean[] = [];
  searchQuery: string = '';

  constructor(private videoService: VideoService, private router: Router) {}

  ngOnInit(): void {
    this.videos = this.videoService.getVideos();
    this.activePreviews = new Array(this.videos.length).fill(false);
  }

  filteredVideos(): Video[] {
    return this.videos.filter(video =>
      video.title.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
      (video.channel || '').toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  }

  startPreview(index: number) {
    const videoElements = this.videoPreviews.toArray();
    if (videoElements[index]) {
      const videoEl = videoElements[index].nativeElement;
      videoEl.currentTime = 0;
      videoEl.play()
        .then(() => this.activePreviews[index] = true)
        .catch(err => {
          console.error('Error playing video preview:', err);
          this.activePreviews[index] = false;
        });
    }
  }

  stopPreview(index: number) {
    const videoElements = this.videoPreviews.toArray();
    if (videoElements[index]) {
      videoElements[index].nativeElement.pause();
      this.activePreviews[index] = false;
    }
  }

  play(id: number) {
    this.router.navigate(['/videos', id]);
  }

  openSettings(video: Video) {
    alert(`Settings for video: ${video.title}`);
  }

  getVideoPoster(video: Video): string {
    return '';
  }

  getChannelIcon(video: Video): string {
    return video.channelIcon || '/EFM.png';
  }

  getChannelName(video: Video): string {
    return video.channel || 'EFM Community';
  }

  getViewCount(video: Video): string {
    const views = video.views || Math.floor(Math.random() * 10000000);
    return this.formatViews(views);
  }

  getUploadTime(video: Video): string {
    return video.uploadTime || this.randomUploadTime();
  }

  getDuration(video: Video): string {
    return video.duration || this.randomDuration();
  }

  private formatViews(views: number): string {
    if (views >= 1_000_000) return `${(views / 1_000_000).toFixed(1)}M`;
    if (views >= 1_000) return `${(views / 1_000).toFixed(1)}K`;
    return views.toString();
  }

  private randomUploadTime(): string {
    const times = ['1 hour', '2 days', '1 week', '3 months', '1 year'];
    return times[Math.floor(Math.random() * times.length)];
  }

  private randomDuration(): string {
    const minutes = Math.floor(Math.random() * 60) + 1;
    const seconds = Math.floor(Math.random() * 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }
}