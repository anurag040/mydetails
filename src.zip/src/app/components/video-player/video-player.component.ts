import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { VideoService, Video } from '../../services/video.service';

@Component({
  selector: 'app-video-player',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './video-player.component.html',
  styleUrls: ['./video-player.component.scss'],
})
export class VideoPlayerComponent implements OnInit {
  video?: Video;
  newComment = '';

  constructor(private route: ActivatedRoute, private videoService: VideoService) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.video = this.videoService.getVideoById(id);
  }

  like() {
    if (this.video) {
      this.videoService.likeVideo(this.video.id);
    }
  }

  addComment() {
    if (this.video && this.newComment.trim()) {
      this.videoService.addComment(this.video.id, this.newComment.trim());
      this.newComment = '';
    }
  }
}
