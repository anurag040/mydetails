import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { VideoService } from '../../services/video.service';

@Component({
  selector: 'app-video-upload',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './video-upload.component.html',
  styleUrls: ['./video-upload.component.scss']
})
export class VideoUploadComponent {
  title = '';
  file?: File;
  visibility = 'private';
  isDragging = false;
  uploadProgress = 0;
  isUploading = false;

  constructor(public router: Router, private videoService: VideoService) {}

  onFileSelected(event: any) {
    this.file = event.target.files[0];
  }

  upload() {
    if (!this.title || !this.file || this.isUploading) return;
    
    this.isUploading = true;
    this.uploadProgress = 0;
    
    // Simulate upload progress over 5 seconds
    const interval = setInterval(() => {
      this.uploadProgress += 5;
      if (this.uploadProgress >= 100) {
        clearInterval(interval);
        this.uploadComplete();
      }
    }, 250);
  }

  uploadComplete() {
    const url = this.file ? URL.createObjectURL(this.file) : '';
    this.videoService.uploadVideo(this.title, url);
    setTimeout(() => {
      this.router.navigate(['/videos']);
    }, 500);
  }
}