import { Injectable } from '@angular/core';

export interface Video {
  id: number;
  title: string;
  fileUrl: string;
  thumbnailUrl?: string;
  likes: number;
  comments: string[];
  channel?: string;
  channelIcon?: string;
  views?: number;
  uploadTime?: string;
  duration?: string;
}

@Injectable({
  providedIn: 'root'
})
export class VideoService {
  private videos: Video[] = [];
  private idCounter = 1;

  getVideos(): Video[] {
    return this.videos;
  }

  uploadVideo(title: string, fileUrl: string): void {
    this.videos.push({
      id: this.idCounter++,
      title,
      fileUrl,
      likes: 0,
      comments: []
    });
  }

  getVideoById(id: number): Video | undefined {
    return this.videos.find(v => v.id === id);
  }

  likeVideo(id: number): void {
    const video = this.getVideoById(id);
    if (video) video.likes++;
  }

  addComment(id: number, comment: string): void {
    const video = this.getVideoById(id);
    if (video) video.comments.push(comment);
  }
}
